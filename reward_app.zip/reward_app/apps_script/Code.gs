/**
 * Paste this into Extensions -> Apps Script on your Google Sheet, then
 * deploy as a Web App (Execute as: Me, Who has access: Anyone).
 * The deployment URL goes into lib/services/sheets_service.dart (_webhookUrl).
 *
 * The sheet will get a header row automatically the first time a request
 * comes in, then one row per withdraw request after that.
 */

function doPost(e) {
  try {
    var sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName('Withdraws')
      || SpreadsheetApp.getActiveSpreadsheet().insertSheet('Withdraws');

    if (sheet.getLastRow() === 0) {
      sheet.appendRow([
        'Request ID', 'User ID', 'User Name', 'Method',
        'Account Number', 'Points Used', 'Amount (BDT)', 'Date', 'Status'
      ]);
    }

    var data = JSON.parse(e.postData.contents);

    sheet.appendRow([
      data.id,
      data.uid,
      data.userName,
      data.method,
      data.accountNumber,
      data.pointsUsed,
      data.amountBDT,
      data.date,
      data.status || 'Pending'
    ]);

    return ContentService
      .createTextOutput(JSON.stringify({ status: 'success' }))
      .setMimeType(ContentService.MimeType.JSON);
  } catch (err) {
    return ContentService
      .createTextOutput(JSON.stringify({ status: 'error', message: err.toString() }))
      .setMimeType(ContentService.MimeType.JSON);
  }
}

function doGet(e) {
  return ContentService
    .createTextOutput(JSON.stringify({ status: 'ok', message: 'Withdraw webhook is live' }))
    .setMimeType(ContentService.MimeType.JSON);
}
