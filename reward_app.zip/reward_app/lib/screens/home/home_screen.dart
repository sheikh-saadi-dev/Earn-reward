import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../services/ad_service.dart';
import '../../services/auth_service.dart';
import '../../services/points_service.dart';
import '../../theme/app_theme.dart';
import '../../widgets/gradient_button.dart';
import '../../widgets/point_card.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  bool _adLoading = false;

  Future<void> _watchAd() async {
    final points = context.read<PointsService>();

    if (!points.canWatchAdToday) {
      _showSnack('আজকের জন্য সর্বোচ্চ সীমায় পৌঁছে গেছেন। আগামীকাল আবার আসুন!');
      return;
    }

    setState(() => _adLoading = true);
    await AdService().showAd(
      onUserEarnedReward: () async {
        final earned = await points.addAdReward();
        if (mounted) {
          _showRewardDialog(earned);
        }
      },
      onDismissed: () {
        if (mounted) setState(() => _adLoading = false);
      },
      onNotReady: (msg) {
        if (mounted) {
          setState(() => _adLoading = false);
          _showSnack(msg);
        }
      },
    );
  }

  void _showSnack(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  }

  void _showRewardDialog(int earned) {
    showDialog(
      context: context,
      builder: (_) => Dialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        child: Padding(
          padding: const EdgeInsets.all(28),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                padding: const EdgeInsets.all(18),
                decoration: const BoxDecoration(
                  gradient: AppColors.goldGradient,
                  shape: BoxShape.circle,
                ),
                child: const Icon(Icons.celebration_rounded,
                    color: Colors.white, size: 40),
              ),
              const SizedBox(height: 16),
              const Text('অভিনন্দন! 🎉',
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
              const SizedBox(height: 6),
              Text('আপনি +$earned points পেয়েছেন',
                  style: const TextStyle(color: AppColors.textMuted)),
              const SizedBox(height: 20),
              GradientButton(
                label: 'ঠিক আছে',
                onPressed: () => Navigator.pop(context),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final points = context.watch<PointsService>();
    final user = context.watch<AuthService>().currentUser;

    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(20, 12, 20, 100),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('হ্যালো 👋',
                      style: TextStyle(color: AppColors.textMuted)),
                  Text(
                    user?.name ?? user?.phone ?? 'বন্ধু',
                    style: const TextStyle(
                        fontSize: 20, fontWeight: FontWeight.bold),
                  ),
                ],
              ),
              CircleAvatar(
                radius: 24,
                backgroundColor: AppColors.primary.withOpacity(0.1),
                backgroundImage:
                    user?.photoUrl != null ? NetworkImage(user!.photoUrl!) : null,
                child: user?.photoUrl == null
                    ? const Icon(Icons.person, color: AppColors.primary)
                    : null,
              ),
            ],
          ),
          const SizedBox(height: 20),
          PointCard(
            points: points.points,
            bdtValue: points.pointsToBDT(points.points),
          ),
          const SizedBox(height: 24),
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(20),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.04),
                  blurRadius: 16,
                  offset: const Offset(0, 6),
                ),
              ],
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: AppColors.secondary.withOpacity(0.12),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: const Icon(Icons.play_circle_fill_rounded,
                          color: AppColors.secondary, size: 26),
                    ),
                    const SizedBox(width: 12),
                    const Expanded(
                      child: Text(
                        'ভিডিও দেখে পয়েন্ট আয় করুন',
                        style: TextStyle(
                            fontSize: 15, fontWeight: FontWeight.w600),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 14),
                Text(
                  'প্রতিটি ভিডিওতে +${PointsService.pointsPerAd} পয়েন্ট। আজ দেখেছেন: '
                  '${points.adsWatchedToday}/${PointsService.maxAdsPerDay}',
                  style: const TextStyle(
                      color: AppColors.textMuted, fontSize: 13),
                ),
                const SizedBox(height: 6),
                ClipRRect(
                  borderRadius: BorderRadius.circular(10),
                  child: LinearProgressIndicator(
                    value: points.adsWatchedToday / PointsService.maxAdsPerDay,
                    minHeight: 8,
                    backgroundColor: AppColors.background,
                    valueColor:
                        const AlwaysStoppedAnimation(AppColors.secondary),
                  ),
                ),
                const SizedBox(height: 18),
                GradientButton(
                  label: 'Watch Video & Earn',
                  icon: Icons.play_arrow_rounded,
                  loading: _adLoading,
                  onPressed: points.canWatchAdToday ? _watchAd : null,
                ),
              ],
            ),
          ),
          const SizedBox(height: 20),
          const Text('কীভাবে কাজ করে',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
          const SizedBox(height: 12),
          _StepTile(
            icon: Icons.ondemand_video_rounded,
            title: 'ভিডিও দেখুন',
            subtitle: 'বাটনে ট্যাপ করে সম্পূর্ণ ভিডিও দেখুন',
          ),
          _StepTile(
            icon: Icons.bolt_rounded,
            title: 'পয়েন্ট পান',
            subtitle: 'প্রতি ভিডিওতে সাথে সাথে পয়েন্ট যোগ হবে',
          ),
          _StepTile(
            icon: Icons.account_balance_wallet_rounded,
            title: 'ক্যাশ আউট করুন',
            subtitle: 'বিকাশ বা নগদে সরাসরি টাকা তুলুন',
          ),
        ],
      ),
    );
  }
}

class _StepTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;

  const _StepTile({
    required this.icon,
    required this.title,
    required this.subtitle,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: AppColors.primary.withOpacity(0.1),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(icon, color: AppColors.primary, size: 22),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title,
                      style:
                          const TextStyle(fontWeight: FontWeight.w600)),
                  Text(subtitle,
                      style: const TextStyle(
                          color: AppColors.textMuted, fontSize: 12)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
