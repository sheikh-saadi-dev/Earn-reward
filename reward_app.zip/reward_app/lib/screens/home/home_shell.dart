import 'package:flutter/material.dart';

import '../../widgets/custom_bottom_nav.dart';
import '../profile/profile_screen.dart';
import '../withdraw/withdraw_screen.dart';
import 'daily_reward_screen.dart';
import 'home_screen.dart';

/// Hosts the 4 main tabs behind the bottom navigation bar.
class HomeShell extends StatefulWidget {
  const HomeShell({super.key});

  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int _index = 0;

  final _pages = const [
    HomeScreen(),
    DailyRewardScreen(),
    WithdrawScreen(),
    ProfileScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: IndexedStack(index: _index, children: _pages),
      ),
      bottomNavigationBar: CustomBottomNav(
        currentIndex: _index,
        onTap: (i) => setState(() => _index = i),
      ),
    );
  }
}
