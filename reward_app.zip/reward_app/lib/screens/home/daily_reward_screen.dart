import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../services/points_service.dart';
import '../../theme/app_theme.dart';
import '../../widgets/gradient_button.dart';

class DailyRewardScreen extends StatefulWidget {
  const DailyRewardScreen({super.key});

  @override
  State<DailyRewardScreen> createState() => _DailyRewardScreenState();
}

class _DailyRewardScreenState extends State<DailyRewardScreen> {
  bool _claiming = false;

  Future<void> _claim() async {
    setState(() => _claiming = true);
    final points = context.read<PointsService>();
    final reward = await points.claimDailyReward();
    setState(() => _claiming = false);

    if (reward > 0 && mounted) {
      showDialog(
        context: context,
        builder: (_) => Dialog(
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
          child: Padding(
            padding: const EdgeInsets.all(28),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.card_giftcard_rounded,
                    color: AppColors.gold, size: 48),
                const SizedBox(height: 14),
                const Text('ডেইলি রিওয়ার্ড পেয়েছেন!',
                    style: TextStyle(
                        fontSize: 18, fontWeight: FontWeight.bold)),
                const SizedBox(height: 6),
                Text('+$reward points',
                    style: const TextStyle(color: AppColors.textMuted)),
                const SizedBox(height: 18),
                GradientButton(
                    label: 'দারুণ!', onPressed: () => Navigator.pop(context)),
              ],
            ),
          ),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final points = context.watch<PointsService>();
    final streak = points.dailyStreak;

    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(20, 12, 20, 100),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('ডেইলি রিওয়ার্ড',
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
          const SizedBox(height: 4),
          const Text('প্রতিদিন লগইন করে বোনাস পয়েন্ট সংগ্রহ করুন',
              style: TextStyle(color: AppColors.textMuted)),
          const SizedBox(height: 24),
          GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: 7,
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 4,
              crossAxisSpacing: 10,
              mainAxisSpacing: 10,
              childAspectRatio: 0.85,
            ),
            itemBuilder: (context, i) {
              final day = i + 1;
              final reached = day <= streak;
              final isNext = day == (streak % 7) + 1 && points.canClaimDailyReward;
              final reward = 30 + (day * 10);

              return Container(
                decoration: BoxDecoration(
                  gradient: reached ? AppColors.goldGradient : null,
                  color: reached ? null : Colors.white,
                  borderRadius: BorderRadius.circular(16),
                  border: isNext
                      ? Border.all(color: AppColors.primary, width: 2)
                      : null,
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text('Day $day',
                        style: TextStyle(
                          fontSize: 11,
                          fontWeight: FontWeight.w600,
                          color: reached ? Colors.white : AppColors.textMuted,
                        )),
                    const SizedBox(height: 4),
                    Icon(
                      reached
                          ? Icons.check_circle_rounded
                          : Icons.card_giftcard_rounded,
                      color: reached ? Colors.white : AppColors.primary,
                      size: 22,
                    ),
                    const SizedBox(height: 4),
                    Text('+$reward',
                        style: TextStyle(
                          fontSize: 11,
                          fontWeight: FontWeight.bold,
                          color: reached ? Colors.white : AppColors.textDark,
                        )),
                  ],
                ),
              );
            },
          ),
          const SizedBox(height: 28),
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(20),
            ),
            child: Column(
              children: [
                Text(
                  points.canClaimDailyReward
                      ? 'আজকের রিওয়ার্ড সংগ্রহ করুন'
                      : 'আজকের রিওয়ার্ড সংগ্রহ করা হয়ে গেছে ✅',
                  style: const TextStyle(fontWeight: FontWeight.w600),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 4),
                Text('বর্তমান স্ট্রিক: $streak দিন',
                    style: const TextStyle(color: AppColors.textMuted)),
                const SizedBox(height: 16),
                GradientButton(
                  label: points.canClaimDailyReward
                      ? 'Claim Reward'
                      : 'আগামীকাল আবার আসুন',
                  icon: Icons.redeem_rounded,
                  loading: _claiming,
                  onPressed: points.canClaimDailyReward ? _claim : null,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
