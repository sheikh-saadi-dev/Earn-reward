import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:uuid/uuid.dart';

import '../../models/app_user.dart';
import '../../services/auth_service.dart';
import '../../services/points_service.dart';
import '../../services/sheets_service.dart';
import '../../theme/app_theme.dart';
import '../../widgets/gradient_button.dart';
import 'withdraw_history_screen.dart';

class WithdrawScreen extends StatefulWidget {
  const WithdrawScreen({super.key});

  @override
  State<WithdrawScreen> createState() => _WithdrawScreenState();
}

class _WithdrawScreenState extends State<WithdrawScreen> {
  final _formKey = GlobalKey<FormState>();
  final _accountCtrl = TextEditingController();
  final _pointsCtrl = TextEditingController();
  String _method = 'bKash';
  bool _submitting = false;

  @override
  void dispose() {
    _accountCtrl.dispose();
    _pointsCtrl.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;

    final points = context.read<PointsService>();
    final auth = context.read<AuthService>();
    final user = auth.currentUser;
    final requestedPoints = int.parse(_pointsCtrl.text.trim());

    if (!points.canWithdraw(requestedPoints)) {
      _showSnack(
          'ন্যূনতম ${PointsService.minWithdrawPoints} পয়েন্ট প্রয়োজন, অথবা আপনার ব্যালেন্স যথেষ্ট নয়।');
      return;
    }

    setState(() => _submitting = true);

    final request = WithdrawRequest(
      id: const Uuid().v4(),
      uid: user?.uid ?? 'unknown',
      userName: user?.name ?? user?.phone ?? user?.email ?? 'Unknown',
      method: _method,
      accountNumber: _accountCtrl.text.trim(),
      pointsUsed: requestedPoints,
      amountBDT: points.pointsToBDT(requestedPoints),
      date: DateTime.now(),
    );

    final success = await SheetsService.submitWithdrawRequest(request);

    if (success) {
      await points.deductPoints(requestedPoints);
      await points.addWithdrawToLocalHistory(request);
      _accountCtrl.clear();
      _pointsCtrl.clear();
      if (mounted) {
        _showSnack('উত্তোলনের অনুরোধ সফলভাবে পাঠানো হয়েছে ✅');
      }
    } else {
      if (mounted) {
        _showSnack(
            'অনুরোধ পাঠাতে সমস্যা হয়েছে। ইন্টারনেট চেক করে আবার চেষ্টা করুন।');
      }
    }

    if (mounted) setState(() => _submitting = false);
  }

  void _showSnack(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  }

  @override
  Widget build(BuildContext context) {
    final points = context.watch<PointsService>();

    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(20, 12, 20, 100),
      child: Form(
        key: _formKey,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text('Withdraw',
                    style:
                        TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                TextButton.icon(
                  onPressed: () => Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (_) => const WithdrawHistoryScreen()),
                  ),
                  icon: const Icon(Icons.history_rounded, size: 18),
                  label: const Text('History'),
                ),
              ],
            ),
            Text(
              'বর্তমান ব্যালেন্স: ${points.points} পয়েন্ট (≈ ৳${points.pointsToBDT(points.points).toStringAsFixed(2)})',
              style: const TextStyle(color: AppColors.textMuted),
            ),
            const SizedBox(height: 20),
            const Text('পেমেন্ট মেথড নির্বাচন করুন',
                style: TextStyle(fontWeight: FontWeight.w600)),
            const SizedBox(height: 10),
            Row(
              children: [
                Expanded(
                  child: _MethodTile(
                    label: 'bKash',
                    color: AppColors.bkash,
                    selected: _method == 'bKash',
                    onTap: () => setState(() => _method = 'bKash'),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: _MethodTile(
                    label: 'Nagad',
                    color: AppColors.nagad,
                    selected: _method == 'Nagad',
                    onTap: () => setState(() => _method = 'Nagad'),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 20),
            const Text('অ্যাকাউন্ট নম্বর',
                style: TextStyle(fontWeight: FontWeight.w600)),
            const SizedBox(height: 8),
            TextFormField(
              controller: _accountCtrl,
              keyboardType: TextInputType.phone,
              decoration: InputDecoration(
                hintText: '01XXXXXXXXX ($_method নম্বর)',
                prefixIcon: const Icon(Icons.smartphone_rounded),
              ),
              validator: (v) {
                if (v == null || v.trim().length < 11) {
                  return 'সঠিক মোবাইল নম্বর দিন';
                }
                return null;
              },
            ),
            const SizedBox(height: 16),
            const Text('কত পয়েন্ট উত্তোলন করবেন?',
                style: TextStyle(fontWeight: FontWeight.w600)),
            const SizedBox(height: 8),
            TextFormField(
              controller: _pointsCtrl,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                hintText: 'ন্যূনতম ${PointsService.minWithdrawPoints}',
                prefixIcon: const Icon(Icons.numbers_rounded),
              ),
              validator: (v) {
                final n = int.tryParse(v ?? '');
                if (n == null) return 'পয়েন্টের পরিমাণ দিন';
                if (n < PointsService.minWithdrawPoints) {
                  return 'ন্যূনতম ${PointsService.minWithdrawPoints} পয়েন্ট প্রয়োজন';
                }
                if (n > points.points) return 'পর্যাপ্ত ব্যালেন্স নেই';
                return null;
              },
            ),
            const SizedBox(height: 24),
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: AppColors.primary.withOpacity(0.06),
                borderRadius: BorderRadius.circular(14),
              ),
              child: const Row(
                children: [
                  Icon(Icons.info_outline_rounded,
                      color: AppColors.primary, size: 20),
                  SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      'অনুরোধ পাঠানোর ২৪-৪৮ ঘন্টার মধ্যে টাকা পাঠানো হবে।',
                      style: TextStyle(fontSize: 12.5, color: AppColors.textDark),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),
            GradientButton(
              label: 'Submit Withdraw Request',
              icon: Icons.send_rounded,
              loading: _submitting,
              onPressed: _submit,
            ),
          ],
        ),
      ),
    );
  }
}

class _MethodTile extends StatelessWidget {
  final String label;
  final Color color;
  final bool selected;
  final VoidCallback onTap;

  const _MethodTile({
    required this.label,
    required this.color,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(16),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 150),
        padding: const EdgeInsets.symmetric(vertical: 16),
        decoration: BoxDecoration(
          color: selected ? color.withOpacity(0.12) : Colors.white,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: selected ? color : const Color(0xFFEDEBF7),
            width: selected ? 2 : 1,
          ),
        ),
        child: Column(
          children: [
            Icon(Icons.account_balance_wallet_rounded, color: color),
            const SizedBox(height: 6),
            Text(label,
                style: TextStyle(
                    fontWeight: FontWeight.w700,
                    color: selected ? color : AppColors.textDark)),
          ],
        ),
      ),
    );
  }
}
