import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../services/auth_service.dart';
import '../../theme/app_theme.dart';
import '../../widgets/gradient_button.dart';
import '../home/home_shell.dart';

class PhoneOtpScreen extends StatefulWidget {
  final String initialPhone;
  const PhoneOtpScreen({super.key, this.initialPhone = '+880'});

  @override
  State<PhoneOtpScreen> createState() => _PhoneOtpScreenState();
}

class _PhoneOtpScreenState extends State<PhoneOtpScreen> {
  late final TextEditingController _phoneCtrl =
      TextEditingController(text: widget.initialPhone);
  final _otpCtrl = TextEditingController();

  bool _codeSent = false;
  bool _loading = false;
  String? _verificationId;
  String? _error;

  Future<void> _sendCode() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    final auth = context.read<AuthService>();
    await auth.startPhoneVerification(
      phoneNumber: _phoneCtrl.text.trim(),
      onCodeSent: (id) {
        setState(() {
          _verificationId = id;
          _codeSent = true;
          _loading = false;
        });
      },
      onError: (msg) {
        setState(() {
          _error = msg;
          _loading = false;
        });
      },
      onAutoVerified: () {
        if (mounted) {
          Navigator.of(context).pushReplacement(
            MaterialPageRoute(builder: (_) => const HomeShell()),
          );
        }
      },
    );
  }

  Future<void> _verifyCode() async {
    if (_verificationId == null) return;
    setState(() {
      _loading = true;
      _error = null;
    });
    final auth = context.read<AuthService>();
    try {
      final user = await auth.verifyOtp(
        verificationId: _verificationId!,
        smsCode: _otpCtrl.text.trim(),
      );
      if (user != null && mounted) {
        Navigator.of(context).pushReplacement(
          MaterialPageRoute(builder: (_) => const HomeShell()),
        );
      }
    } catch (e) {
      setState(() => _error = 'ভুল OTP কোড। আবার চেষ্টা করুন।');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Phone Verification')),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                _codeSent ? 'কোড দিন' : 'আপনার নম্বর দিন',
                style: const TextStyle(
                    fontSize: 22, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 6),
              Text(
                _codeSent
                    ? '${_phoneCtrl.text} নম্বরে পাঠানো ৬ ডিজিটের কোডটি লিখুন'
                    : 'আমরা একটি OTP কোড পাঠাবো (+৮৮০ সহ নম্বর দিন)',
                style: const TextStyle(color: AppColors.textMuted),
              ),
              const SizedBox(height: 28),
              if (!_codeSent)
                TextField(
                  controller: _phoneCtrl,
                  keyboardType: TextInputType.phone,
                  decoration: const InputDecoration(
                    hintText: '+8801XXXXXXXXX',
                    prefixIcon: Icon(Icons.phone_rounded),
                  ),
                )
              else
                TextField(
                  controller: _otpCtrl,
                  keyboardType: TextInputType.number,
                  maxLength: 6,
                  textAlign: TextAlign.center,
                  style: const TextStyle(fontSize: 24, letterSpacing: 8),
                  decoration: const InputDecoration(
                    counterText: '',
                    hintText: '------',
                  ),
                ),
              if (_error != null) ...[
                const SizedBox(height: 12),
                Text(_error!, style: const TextStyle(color: AppColors.danger)),
              ],
              const SizedBox(height: 24),
              GradientButton(
                label: _codeSent ? 'Verify & Continue' : 'Send OTP',
                loading: _loading,
                onPressed: _codeSent ? _verifyCode : _sendCode,
              ),
              if (_codeSent) ...[
                const SizedBox(height: 12),
                Center(
                  child: TextButton(
                    onPressed: _loading
                        ? null
                        : () => setState(() {
                              _codeSent = false;
                              _otpCtrl.clear();
                            }),
                    child: const Text('নম্বর পরিবর্তন করুন'),
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}
