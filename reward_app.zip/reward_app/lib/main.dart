import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'screens/splash_screen.dart';
import 'services/auth_service.dart';
import 'services/points_service.dart';
import 'theme/app_theme.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Requires google-services.json (Android) / GoogleService-Info.plist (iOS)
  // to be added to the project — see README.md "Firebase setup".
  await Firebase.initializeApp();

  runApp(const EarnRewardApp());
}

class EarnRewardApp extends StatelessWidget {
  const EarnRewardApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => AuthService()),
        ChangeNotifierProvider(create: (_) => PointsService()),
      ],
      child: MaterialApp(
        title: 'Earn Reward',
        debugShowCheckedModeBanner: false,
        theme: AppTheme.light,
        home: const SplashScreen(),
      ),
    );
  }
}
