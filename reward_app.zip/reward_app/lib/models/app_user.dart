class AppUser {
  final String uid;
  final String? name;
  final String? email;
  final String? phone;
  final String? photoUrl;

  AppUser({
    required this.uid,
    this.name,
    this.email,
    this.phone,
    this.photoUrl,
  });

  Map<String, dynamic> toMap() => {
        'uid': uid,
        'name': name,
        'email': email,
        'phone': phone,
        'photoUrl': photoUrl,
      };

  factory AppUser.fromMap(Map<String, dynamic> map) => AppUser(
        uid: map['uid'] ?? '',
        name: map['name'],
        email: map['email'],
        phone: map['phone'],
        photoUrl: map['photoUrl'],
      );
}

/// One row of withdraw history, mirrors what gets sent to Google Sheets.
class WithdrawRequest {
  final String id;
  final String uid;
  final String userName;
  final String method; // bKash / Nagad
  final String accountNumber;
  final int pointsUsed;
  final double amountBDT;
  final DateTime date;
  final String status; // pending / approved / rejected

  WithdrawRequest({
    required this.id,
    required this.uid,
    required this.userName,
    required this.method,
    required this.accountNumber,
    required this.pointsUsed,
    required this.amountBDT,
    required this.date,
    this.status = 'Pending',
  });

  Map<String, dynamic> toMap() => {
        'id': id,
        'uid': uid,
        'userName': userName,
        'method': method,
        'accountNumber': accountNumber,
        'pointsUsed': pointsUsed,
        'amountBDT': amountBDT,
        'date': date.toIso8601String(),
        'status': status,
      };

  factory WithdrawRequest.fromMap(Map<String, dynamic> map) => WithdrawRequest(
        id: map['id'],
        uid: map['uid'],
        userName: map['userName'],
        method: map['method'],
        accountNumber: map['accountNumber'],
        pointsUsed: map['pointsUsed'],
        amountBDT: (map['amountBDT'] as num).toDouble(),
        date: DateTime.parse(map['date']),
        status: map['status'] ?? 'Pending',
      );
}
