import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/foundation.dart';
import 'package:google_sign_in/google_sign_in.dart';

import '../models/app_user.dart';

/// Wraps Firebase Auth so the rest of the app never talks to Firebase directly.
/// Supports both Google Sign-In and Phone (OTP) sign-in, as requested.
class AuthService extends ChangeNotifier {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final GoogleSignIn _googleSignIn = GoogleSignIn(scopes: ['email']);

  User? get firebaseUser => _auth.currentUser;
  bool get isLoggedIn => _auth.currentUser != null;

  AppUser? get currentUser {
    final u = _auth.currentUser;
    if (u == null) return null;
    return AppUser(
      uid: u.uid,
      name: u.displayName,
      email: u.email,
      phone: u.phoneNumber,
      photoUrl: u.photoURL,
    );
  }

  Stream<User?> get authStateChanges => _auth.authStateChanges();

  // ---------------- Google Sign-In ----------------
  Future<AppUser?> signInWithGoogle() async {
    final googleUser = await _googleSignIn.signIn();
    if (googleUser == null) return null; // user cancelled

    final googleAuth = await googleUser.authentication;
    final credential = GoogleAuthProvider.credential(
      accessToken: googleAuth.accessToken,
      idToken: googleAuth.idToken,
    );

    final result = await _auth.signInWithCredential(credential);
    notifyListeners();
    final u = result.user;
    if (u == null) return null;
    return AppUser(
      uid: u.uid,
      name: u.displayName,
      email: u.email,
      photoUrl: u.photoURL,
    );
  }

  // ---------------- Phone OTP Sign-In ----------------
  /// Starts phone verification. [onCodeSent] gives you the verificationId
  /// to pass into [verifyOtp]. [onAutoVerified] fires on Android when the
  /// OTP is auto-detected (no manual code entry needed).
  Future<void> startPhoneVerification({
    required String phoneNumber, // e.g. +8801XXXXXXXXX
    required void Function(String verificationId) onCodeSent,
    required void Function(String error) onError,
    void Function()? onAutoVerified,
  }) async {
    await _auth.verifyPhoneNumber(
      phoneNumber: phoneNumber,
      timeout: const Duration(seconds: 60),
      verificationCompleted: (PhoneAuthCredential credential) async {
        await _auth.signInWithCredential(credential);
        notifyListeners();
        if (onAutoVerified != null) onAutoVerified();
      },
      verificationFailed: (FirebaseAuthException e) {
        onError(e.message ?? 'Phone verification failed');
      },
      codeSent: (String verificationId, int? resendToken) {
        onCodeSent(verificationId);
      },
      codeAutoRetrievalTimeout: (String verificationId) {},
    );
  }

  Future<AppUser?> verifyOtp({
    required String verificationId,
    required String smsCode,
  }) async {
    final credential = PhoneAuthProvider.credential(
      verificationId: verificationId,
      smsCode: smsCode,
    );
    final result = await _auth.signInWithCredential(credential);
    notifyListeners();
    final u = result.user;
    if (u == null) return null;
    return AppUser(uid: u.uid, phone: u.phoneNumber);
  }

  Future<void> signOut() async {
    await _googleSignIn.signOut();
    await _auth.signOut();
    notifyListeners();
  }
}
