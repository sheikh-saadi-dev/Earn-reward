import 'dart:io';
import 'package:google_mobile_ads/google_mobile_ads.dart';

/// Wraps loading/showing a Rewarded video ad.
///
/// ⚠️ IMPORTANT: Replace the test ad unit IDs below with YOUR real AdMob
/// Rewarded Ad Unit IDs before release (you said you already have an
/// AdMob account — create a "Rewarded" ad unit for Android & iOS in the
/// AdMob console and paste the IDs here). Using test IDs in production
/// violates AdMob policy.
class AdService {
  static final AdService _instance = AdService._internal();
  factory AdService() => _instance;
  AdService._internal();

  RewardedAd? _rewardedAd;
  bool _isLoading = false;

  String get _adUnitId {
    if (Platform.isAndroid) {
      // TEST ID — replace with your real Android rewarded ad unit id
      return 'ca-app-pub-3940256099942544/5224354917';
    } else if (Platform.isIOS) {
      // TEST ID — replace with your real iOS rewarded ad unit id
      return 'ca-app-pub-3940256099942544/1712485313';
    }
    throw UnsupportedError('Unsupported platform for ads');
  }

  Future<void> init() async {
    await MobileAds.instance.initialize();
    _loadAd();
  }

  void _loadAd() {
    if (_isLoading) return;
    _isLoading = true;
    RewardedAd.load(
      adUnitId: _adUnitId,
      request: const AdRequest(),
      rewardedAdLoadCallback: RewardedAdLoadCallback(
        onAdLoaded: (ad) {
          _rewardedAd = ad;
          _isLoading = false;
        },
        onAdFailedToLoad: (error) {
          _rewardedAd = null;
          _isLoading = false;
        },
      ),
    );
  }

  bool get isAdReady => _rewardedAd != null;

  /// Shows the rewarded ad. [onUserEarnedReward] fires only if the user
  /// watches the ad to completion. [onDismissed] always fires when the ad
  /// closes (used to preload the next ad and to reset any loading UI).
  Future<void> showAd({
    required void Function() onUserEarnedReward,
    required void Function() onDismissed,
    required void Function(String message) onNotReady,
  }) async {
    if (_rewardedAd == null) {
      onNotReady('Ad is still loading. Please try again in a few seconds.');
      _loadAd();
      return;
    }

    _rewardedAd!.fullScreenContentCallback = FullScreenContentCallback(
      onAdDismissedFullScreenContent: (ad) {
        ad.dispose();
        _rewardedAd = null;
        _loadAd(); // preload next ad
        onDismissed();
      },
      onAdFailedToShowFullScreenContent: (ad, error) {
        ad.dispose();
        _rewardedAd = null;
        _loadAd();
        onDismissed();
      },
    );

    await _rewardedAd!.show(
      onUserEarnedReward: (ad, reward) {
        onUserEarnedReward();
      },
    );
  }
}
