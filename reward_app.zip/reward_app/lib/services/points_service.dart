import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../models/app_user.dart';

/// Handles points balance, daily reward streak and withdraw history.
///
/// NOTE: This stores data locally per-device via SharedPreferences so the
/// app works even without a backend. For a real production app you'd swap
/// this to Firestore (keyed by uid) so points sync across devices — the
/// public API below is written so that swap only touches this one file.
class PointsService extends ChangeNotifier {
  static const _kPoints = 'points_balance';
  static const _kLastAdWatch = 'last_ad_watch';
  static const _kAdsWatchedToday = 'ads_watched_today';
  static const _kLastDailyReward = 'last_daily_reward';
  static const _kDailyStreak = 'daily_streak';
  static const _kWithdrawHistory = 'withdraw_history';

  int _points = 0;
  int get points => _points;

  int _adsWatchedToday = 0;
  int get adsWatchedToday => _adsWatchedToday;

  int _dailyStreak = 0;
  int get dailyStreak => _dailyStreak;

  DateTime? _lastDailyRewardDate;

  List<WithdrawRequest> _history = [];
  List<WithdrawRequest> get history => List.unmodifiable(_history);

  // Tunable economy settings.
  static const int pointsPerAd = 20;
  static const int maxAdsPerDay = 15;
  static const int pointsPerBDT = 1000; // 1000 points = 1 BDT (tune freely)
  static const int minWithdrawPoints = 50000; // = 50 BDT minimum

  Future<void> load() async {
    final prefs = await SharedPreferences.getInstance();
    _points = prefs.getInt(_kPoints) ?? 0;
    _dailyStreak = prefs.getInt(_kDailyStreak) ?? 0;

    final lastAdStr = prefs.getString(_kLastAdWatch);
    final today = _dateKey(DateTime.now());
    if (lastAdStr == today) {
      _adsWatchedToday = prefs.getInt(_kAdsWatchedToday) ?? 0;
    } else {
      _adsWatchedToday = 0;
    }

    final lastRewardStr = prefs.getString(_kLastDailyReward);
    _lastDailyRewardDate =
        lastRewardStr != null ? DateTime.tryParse(lastRewardStr) : null;

    final historyJson = prefs.getString(_kWithdrawHistory);
    if (historyJson != null) {
      final list = jsonDecode(historyJson) as List;
      _history = list
          .map((e) => WithdrawRequest.fromMap(Map<String, dynamic>.from(e)))
          .toList();
    }
    notifyListeners();
  }

  String _dateKey(DateTime d) => '${d.year}-${d.month}-${d.day}';

  bool get canWatchAdToday => _adsWatchedToday < maxAdsPerDay;

  /// Call this after a rewarded ad finishes successfully.
  Future<int> addAdReward() async {
    final prefs = await SharedPreferences.getInstance();
    _points += pointsPerAd;
    _adsWatchedToday += 1;
    await prefs.setInt(_kPoints, _points);
    await prefs.setInt(_kAdsWatchedToday, _adsWatchedToday);
    await prefs.setString(_kLastAdWatch, _dateKey(DateTime.now()));
    notifyListeners();
    return pointsPerAd;
  }

  bool get canClaimDailyReward {
    if (_lastDailyRewardDate == null) return true;
    final now = DateTime.now();
    return _dateKey(_lastDailyRewardDate!) != _dateKey(now);
  }

  /// Streak-based daily reward: streak resets if a day is missed.
  Future<int> claimDailyReward() async {
    if (!canClaimDailyReward) return 0;
    final prefs = await SharedPreferences.getInstance();
    final now = DateTime.now();

    final isConsecutive = _lastDailyRewardDate != null &&
        now.difference(_lastDailyRewardDate!).inDays <= 2 &&
        _dateKey(_lastDailyRewardDate!) != _dateKey(now);

    _dailyStreak = isConsecutive ? (_dailyStreak % 7) + 1 : 1;
    final reward = 30 + (_dailyStreak * 10); // day1=40 ... day7=100

    _points += reward;
    _lastDailyRewardDate = now;

    await prefs.setInt(_kPoints, _points);
    await prefs.setInt(_kDailyStreak, _dailyStreak);
    await prefs.setString(_kLastDailyReward, now.toIso8601String());
    notifyListeners();
    return reward;
  }

  double pointsToBDT(int pts) => pts / pointsPerBDT;

  bool canWithdraw(int pts) => pts >= minWithdrawPoints && pts <= _points;

  Future<void> deductPoints(int pts) async {
    final prefs = await SharedPreferences.getInstance();
    _points -= pts;
    if (_points < 0) _points = 0;
    await prefs.setInt(_kPoints, _points);
    notifyListeners();
  }

  Future<void> addWithdrawToLocalHistory(WithdrawRequest req) async {
    final prefs = await SharedPreferences.getInstance();
    _history.insert(0, req);
    final encoded = jsonEncode(_history.map((e) => e.toMap()).toList());
    await prefs.setString(_kWithdrawHistory, encoded);
    notifyListeners();
  }
}
