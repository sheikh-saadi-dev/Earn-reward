import 'dart:convert';
import 'package:http/http.dart' as http;

import '../models/app_user.dart';

/// Sends withdraw requests to a Google Sheet through a Google Apps Script
/// "Web App" — no paid backend, no service-account keys needed.
///
/// SETUP (one-time, ~5 minutes):
/// 1. Create a Google Sheet, e.g. "Withdraw Requests".
/// 2. In it, go to Extensions → Apps Script, paste the code from
///    /apps_script/Code.gs (included with this project).
/// 3. Click Deploy → New deployment → type "Web app".
///    - Execute as: Me
///    - Who has access: Anyone
/// 4. Copy the deployment URL and paste it below as [_webhookUrl].
class SheetsService {
  static const String _webhookUrl =
      'https://script.google.com/macros/s/REPLACE_WITH_YOUR_DEPLOYMENT_ID/exec';

  static Future<bool> submitWithdrawRequest(WithdrawRequest req) async {
    try {
      final response = await http.post(
        Uri.parse(_webhookUrl),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode(req.toMap()),
      );
      // Apps Script web apps return 200 with a JSON body on success.
      if (response.statusCode == 200) {
        final body = jsonDecode(response.body);
        return body['status'] == 'success';
      }
      return false;
    } catch (_) {
      return false;
    }
  }
}
